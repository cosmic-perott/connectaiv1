# BRIDGE AI
created by cosmic_perott and renvitz

## To Use Program (on internet)
go to bridgeaiv1.streamlit.app

## To Use Program (locally)
clone git repo
then type 'streamlit run streamlit_app.py' in terminal

## CAUTION
1. use youtube URLs ONLY
2. youtube URL must be in https://www.youtube.com/watch?v=YOUTUBEID format, not youtube.com/watch?v=YOUTUBEID&list=PLAYLISTID
3. the longer your videos are, the longer the video will take to load (1-10 min videos are recommended)
